<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>JRMSU FACIAL RECOGNITION IDENTITY SCANNER</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Poppins:400,700|Roboto:400,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  
  <style>
   
     .face-recognition_container {
    background-image: url(images/background-image.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    text-align: center;
    height: 775px;
    padding: 2rem;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  }
  
    .video-container {
      position: relative;
      margin: 20px auto;
      width: 640px;
      height: 480px;
      margin-right: 50%;
    }
    #video {
      width: 100%;
      height: 100%;
      background-color: #f0f0f0;
      border-radius: 8px;
    }
    #overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .controls {
      margin: 20px 0;
    }
    
 #result {
  position: fixed; /* Changed to fixed positioning */
  top: 25%; /* Distance from top */
  right: 10%; /* Distance from right */
  padding: 15px;
  border-radius: 4px;
  background-color: #052659;
  height: 480px; /* Changed from 50% to auto */
  width: 30%; /* Changed from 40% to fixed width */
  font-weight: bold;
  color: white;
  z-index: 1000; /* Ensure it stays on top */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); 
 text-align: left;
    }

  </style>
  
  <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="main.php">
            <img src="images/Red_Yellow_and_Black_Modern_Vintage_Delivery_Back_to_Business_Landscape_Poster-removebg-preview.png" alt="" />
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
              <ul class="navbar-nav  ">
                <li class="nav-item ">
                  <a class="nav-link" href="main.php">
                    Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item" >
                  <a class="nav-link" href="about.php"> About </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="vmgo.php"> VMGO </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contact.php"> Contact us</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="admin.php"> Admin</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>

  <div class="face-recognition_container">
    <h1>Scan Your ID!</h1>
    <div class="video-container">
      <video id="video" width="640" height="480" autoplay muted></video>
      <canvas id="overlay"></canvas>
    </div>
   
    <div id="result"></div>
    <canvas id="canvas" style="display: none;"></canvas>
  </div>

<script>
    const video = document.getElementById("video");
    const canvas = document.getElementById("canvas");
    const overlay = document.getElementById("overlay");
    const resultDiv = document.getElementById("result");
    
    let isScanning = false;
    let faceDetectionInterval;
    let initialized = false;
    let lastDetectionTime = 0;
    const detectionCooldown = 100; // Reduced cooldown for smoother tracking (100ms)
    let lastFacePosition = null;

    // Create audio elements
    const scanningSound = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-scanning-sci-fi-905.mp3');
    const successSound = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3');
    const errorSound = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-alarm-digital-clock-beep-989.mp3');

    // Initialize face detection and camera
    async function init() {
      try {
        // Show initial message
        resultDiv.innerHTML = "<p style='text-align:center;'>Initializing camera... Please wait</p>";
        
        // Start camera with optimized settings
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 640 },
            height: { ideal: 480 },
            frameRate: { ideal: 30 },
            facingMode: "user" // Ensure front camera is used
          } 
        });
        video.srcObject = stream;
        
        // Load optimized face detection models
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models'),
          faceapi.nets.faceLandmark68Net.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models'),
          faceapi.nets.faceRecognitionNet.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models')
        ]);
        
        // Set up overlay
        const overlayCtx = overlay.getContext('2d');
        
        // Start face detection when video is playing
        video.addEventListener('play', () => {
          overlay.width = video.videoWidth;
          overlay.height = video.videoHeight;
          
          // Show ready message after camera starts
          setTimeout(() => {
            readyForScan();
            initialized = true;
            
            // Start optimized face detection loop with requestAnimationFrame for smoother tracking
            faceDetectionInterval = requestAnimationFrame(detectFaces);
          }, 500);
        });
        
      } catch (err) {
        console.error("Initialization error:", err);
        resultDiv.innerHTML = "Error: " + err.message;
        errorSound.play();
      }
    }

    // Optimized face detection function with smooth tracking
    async function detectFaces() {
      if (!initialized || isScanning) {
        faceDetectionInterval = requestAnimationFrame(detectFaces);
        return;
      }
      
      const now = Date.now();
      if (now - lastDetectionTime < detectionCooldown) {
        faceDetectionInterval = requestAnimationFrame(detectFaces);
        return;
      }
      
      try {
        // Use optimized detection settings
        const detections = await faceapi.detectAllFaces(video, 
          new faceapi.TinyFaceDetectorOptions({
            inputSize: 320,  // Smaller input size for faster processing
            scoreThreshold: 0.5  // Slightly lower threshold for better detection
          })
        ).withFaceLandmarks();
        
        const overlayCtx = overlay.getContext('2d');
        overlayCtx.clearRect(0, 0, overlay.width, overlay.height);
        
        if (detections.length > 0) {
          const detection = detections[0]; // Focus on primary face
          const box = detection.detection.box;
          
          // Smooth transition for the box position
          if (lastFacePosition) {
            // Apply simple smoothing (low-pass filter)
            box.x = lastFacePosition.x * 0.3 + box.x * 0.7;
            box.y = lastFacePosition.y * 0.3 + box.y * 0.7;
            box.width = lastFacePosition.width * 0.3 + box.width * 0.7;
            box.height = lastFacePosition.height * 0.3 + box.height * 0.7;
          }
          lastFacePosition = {...box};
          
          // Draw enhanced detection box
          overlayCtx.beginPath();
          overlayCtx.lineWidth = 4;
          overlayCtx.strokeStyle = "rgba(255, 0, 0, 0.8)";
          overlayCtx.rect(box.x, box.y, box.width, box.height);
          overlayCtx.stroke();
          
          
          // Start scan if face is detected and meets criteria
          if (!isScanning && box.width > 100 && box.width < 300) {
            lastDetectionTime = now;
            captureAndScan();
          }
        } else {
          lastFacePosition = null;
        }
      } catch (err) {
        console.error("Detection error:", err);
      }
      
      faceDetectionInterval = requestAnimationFrame(detectFaces);
    }

    // Ready for scan state
    function readyForScan() {
      resultDiv.innerHTML = "<p style='text-align:center;'>Ready for scanning. Position your face in frame</p>";
      isScanning = false;
    }

    // Capture and scan function
    async function captureAndScan() {
      if (isScanning) return;
      isScanning = true;
      
      try {
        resultDiv.innerHTML = "<p style='text-align:center;'>Scanning...</p>";
        scanningSound.play();
        
        // Capture current frame
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext("2d");
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Simulate processing delay (reduced to 3 seconds)
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Stop scanning sound
        scanningSound.pause();
        scanningSound.currentTime = 0;
        
        // Simulate API response
        const mockResponse = {
          success: true,
          results: ["NAME: JESSICA S. BACULAD", "ID NUMBER: 12345", 
                   "YEAR LEVEL: 2nd Year", "PROGRAM: BACHELOR OF SCIENCE IN COMPUTER SCIENCE"],
          imagePath: "images/123456.jpg"
        };
        
        // Show results
        successSound.play();
        resultDiv.innerHTML = `
          <div class="result-content">
            <div class="result-text">
              <h3>ID Recognized</h3>
              <p>${mockResponse.results.join("<br>")}</p>
            </div>
            <div class="result-image">
              <img src="${mockResponse.imagePath}" alt="Student Photo" style="max-width: 150px; border-radius: 4px;">
            </div>
          </div>
          <style>
            .result-content {
              display: flex;
              gap: 15px;
              align-items: center;
            }
            .result-text {
              flex: 1;
            }
            .result-image {
              flex-shrink: 0;
            }
          </style>
        `;
        
        // Return to ready state after 5 seconds
        setTimeout(() => {
          resultDiv.innerHTML = "<p style='text-align:center;'>Ready for next scan in 5 seconds...</p>";
          
          // Final ready state after 5 seconds
          setTimeout(readyForScan, 5000);
        }, 3000);
        
      } catch (err) {
        console.error("Scan error:", err);
        resultDiv.innerHTML = "<p style='text-align:center;'>ID Unrecognized: " + err.message + "</p>";
        
        // Stop scanning sound and play error sound
        scanningSound.pause();
        scanningSound.currentTime = 0;
        errorSound.play();
        
        // Return to ready state after 5 seconds even on error
        setTimeout(() => {
          resultDiv.innerHTML = "<p style='text-align:center;'>Ready for next scan in 5 seconds...</p>";
          
          // Final ready state after 5 seconds
          setTimeout(readyForScan, 5000);
        }, 3000);
      }
    }
    
    // Initialize everything when page loads
    window.addEventListener('DOMContentLoaded', init);
</script> 

  <!-- footer section -->
  <section class="container-fluid footer_section">
    <p>
      &copy; 2025 All Rights Reserved By JRMSU CCS STUDENTS BLOCK A
      
    </p>
  </section>
</body>
</html>