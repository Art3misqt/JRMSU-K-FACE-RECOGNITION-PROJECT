<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>JRMSU FACIAL RECOGNITION IDENTITY SCANNER</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Poppins:400,700|Roboto:400,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  
  <style>
    .chat-container {
        background-image: url(images/background-image.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        text-align: center;
        height: calc(100vh - 120px);
        padding: 1rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        display: flex;
        flex-direction: column;
        max-width: 100%;
        margin: 0 auto;
    }

    .chat-header {
        background-color: #e6e600;
        color: black;
        padding: 10px 15px;
        text-align: center;
        border-radius: 8px 8px 0 0;
    }

    .chat-header h1 {
        font-size: 1.5rem;
        margin: 0;
    }

    .chat-messages {
        flex: 1;
        padding: 15px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .message {
        max-width: 85%;
        padding: 10px 14px;
        border-radius: 18px;
        line-height: 1.4;
        font-size: 0.95rem;
        word-wrap: break-word;
    }

    .user-message {
        align-self: flex-end;
        background-color: #e6e600;
        color: black;
        border-bottom-right-radius: 4px;
    }

    .ai-message {
        align-self: flex-start;
        background-color: #f1f1f1;
        color: #333;
        border-bottom-left-radius: 4px;
    }

    .chat-input {
        display: flex;
        padding: 10px;
        border-top: 1px solid #eee;
        background-color: #f9f9f9;
        align-items: center;
    }

    .chat-input textarea {
        flex: 1;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 20px;
        resize: none;
        outline: none;
        font-family: inherit;
        font-size: 0.95rem;
        max-height: 120px;
        min-height: 40px;
    }

    .chat-input button {
        margin-left: 8px;
        padding: 8px 15px;
        background-color: #e6e600;
        color: black;
        border: none;
        border-radius: 20px;
        cursor: pointer;
        font-size: 0.95rem;
        transition: background-color 0.3s;
        white-space: nowrap;
    }

    .chat-input button:hover {
        background-color: #d6d600;
    }

    .typing-indicator {
        display: flex;
        padding: 10px 14px;
        background-color: #f1f1f1;
        border-radius: 18px;
        align-self: flex-start;
        border-bottom-left-radius: 4px;
        width: fit-content;
    }

    .typing-indicator span {
        height: 6px;
        width: 6px;
        background-color: #666;
        border-radius: 50%;
        display: inline-block;
        margin: 0 2px;
        animation: bounce 1.5s infinite ease-in-out;
    }

    .typing-indicator span:nth-child(2) {
        animation-delay: 0.2s;
    }

    .typing-indicator span:nth-child(3) {
        animation-delay: 0.4s;
    }

    @keyframes bounce {
        0%, 60%, 100% {
            transform: translateY(0);
        }
        30% {
            transform: translateY(-3px);
        }
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .chat-container {
            height: calc(100vh - 100px);
            padding: 0.5rem;
        }
        
        .chat-header h1 {
            font-size: 1.3rem;
        }
        
        .message {
            max-width: 90%;
            padding: 8px 12px;
            font-size: 0.9rem;
        }
        
        .chat-input {
            padding: 8px;
        }
        
        .chat-input textarea {
            padding: 8px;
            font-size: 0.9rem;
        }
        
        .chat-input button {
            padding: 6px 12px;
            font-size: 0.9rem;
        }
    }

    @media (max-width: 480px) {
        .chat-header h1 {
            font-size: 1.2rem;
        }
        
        .message {
            max-width: 95%;
            font-size: 0.85rem;
        }
        
        .chat-input {
            flex-direction: column;
            gap: 8px;
        }
        
        .chat-input textarea {
            width: 100%;
        }
        
        .chat-input button {
            margin-left: 0;
            width: 100%;
            padding: 8px;
        }
    }
  </style>
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <img src="images/Red_Yellow_and_Black_Modern_Vintage_Delivery_Back_to_Business_Landscape_Poster-removebg-preview.png" alt="" />
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
              <ul class="navbar-nav  ">
                <li class="nav-item ">
                  <a class="nav-link" href="main.php">
                    Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item" >
                  <a class="nav-link" href="about.php"> About </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="vmgo.php"> VMGO </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contact.php"> Contact us</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="admin.php"> Admin</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
    
    <div class="chat-container">
        <div class="chat-header">
            <h1>Dr. Jose</h1>
        </div>
        <div class="chat-messages" id="chat-messages">
            <!-- Messages will appear here -->
        </div>
        <div class="chat-input">
            <textarea id="user-input" placeholder="Type your message here..." rows="1"></textarea>
            <button id="send-button">Send</button>
        </div>
    </div>

    <!-- Audio elements for sound notifications -->
    <audio id="messageSentSound" preload="auto">
        <source src="https://assets.mixkit.co/sfx/preview/mixkit-arcade-game-jump-coin-216.mp3" type="audio/mpeg">
    </audio>
    <audio id="messageReceivedSound" preload="auto">
        <source src="https://assets.mixkit.co/sfx/preview/mixkit-correct-answer-tone-2870.mp3" type="audio/mpeg">
    </audio>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const chatMessages = document.getElementById('chat-messages');
        const userInput = document.getElementById('user-input');
        const sendButton = document.getElementById('send-button');
        const sentSound = document.getElementById('messageSentSound');
        const receivedSound = document.getElementById('messageReceivedSound');
        
        // Auto-resize textarea as user types
        userInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        // Send message when button is clicked or Enter is pressed
        sendButton.addEventListener('click', sendMessage);
        userInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        function sendMessage() {
            const message = userInput.value.trim();
            if (message === '') return;
            
            // Add user message to chat
            addMessage('user', message);
            userInput.value = '';
            userInput.style.height = 'auto';
            
            // Play sent sound
            sentSound.currentTime = 0;
            sentSound.play();
            
            // Show typing indicator
            const typingIndicator = document.createElement('div');
            typingIndicator.className = 'message ai-message typing-indicator';
            typingIndicator.innerHTML = '<span></span><span></span><span></span>';
            chatMessages.appendChild(typingIndicator);
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            // Simulate AI response (replace with actual API call)
            setTimeout(() => {
                // Remove typing indicator
                chatMessages.removeChild(typingIndicator);
                
                // Add AI response to chat
                const responses = [
                    "I'm an AI assistant here to help with JRMSU-related questions.",
                    "Could you clarify your question about the facial recognition system?",
                    "For administrative inquiries, please visit the admin portal.",
                    "The facial recognition system helps verify student identities on campus.",
                    "How can I assist you with JRMSU services today?"
                ];
                const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                addMessage('ai', randomResponse);
                
                // Play received sound
                receivedSound.currentTime = 0;
                receivedSound.play();
            }, 1500);
        }
        
        function addMessage(sender, text) {
            const messageElement = document.createElement('div');
            messageElement.className = `message ${sender}-message`;
            messageElement.textContent = text;
            chatMessages.appendChild(messageElement);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        // Initial greeting
        setTimeout(() => {
            addMessage('ai', "Hello! I'm Dr. Jose, your JRMSU AI assistant. How can I help you today?");
            // Play initial greeting sound
            receivedSound.currentTime = 0;
            receivedSound.play();
        }, 500);
    });
    </script>
  </div>
</body>
</html>